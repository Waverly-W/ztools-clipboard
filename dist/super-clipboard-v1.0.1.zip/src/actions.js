// 条目操作：内置操作 + 设置中配置的自定义操作（转给其他插件处理）
const BUILTIN_ACTIONS = [
  { id: 'copy', name: '复制', icon: 'copy', when: () => true, run: (item) => App.copy([item]) },
  { id: 'view', name: '查看全部', icon: 'view', when: () => true, run: (item) => App.view(item) },
  { id: 'openFolder', name: '打开所在文件夹', icon: 'folder', when: (item) => item.type !== 'text', run: (item) => services.openFolder(item) },
  { id: 'fav', name: '收藏', icon: 'star', when: (item) => !item.fav, run: (item) => App.favorite([item]) },
  { id: 'editFav', name: '编辑收藏', icon: 'edit', when: (item) => item.fav, run: (item) => App.editFavorite(item) },
  { id: 'unfav', name: '取消收藏', icon: 'unstar', when: (item) => item.fav, run: (item) => App.unfavorite([item]) },
  { id: 'delete', name: '删除', icon: 'trash', when: () => true, run: (item) => App.remove([item]) },
  { id: 'split', name: '分词', icon: 'split', when: (item) => item.type === 'text', run: (item) => App.split(item) },
  { id: 'saveFile', name: '保存为文件', icon: 'save', when: (item) => item.type !== 'file', run: (item) => App.saveFile(item) }
]

function customAction(def) {
  let re = null
  if (def.match) {
    try { re = new RegExp(def.match, 'i') } catch {}
  }
  const types = def.types && def.types.length ? def.types : ['text']
  return {
    id: 'custom:' + def.id,
    name: def.name,
    icon: 'bolt',
    custom: true,
    // 只在内容匹配时显示：类型匹配，文字还需匹配正则
    when: (item) => types.includes(item.type) && (!re || (item.type === 'text' && re.test(item.text))),
    run: (item) => runCustomAction(def, item)
  }
}

const PROVIDER_LABELS = { ocr: 'OCR', translation: '翻译' }

// 调用 ZTools 中已启用的翻译 / OCR 服务（由其他插件提供），结果在弹窗中展示
async function runProviderAction(def, item) {
  const zt = window.ztools
  const label = PROVIDER_LABELS[def.provider]
  try {
    const provider = await zt.providers.getDefaultProvider(def.provider)
    if (!provider) {
      App.toast(`未启用${label}服务，请先安装提供${label}的插件，并在 ZTools 设置中启用`)
      return
    }
    App.toast(def.provider === 'ocr' ? '正在识别…' : '正在翻译…')
    const result = def.provider === 'ocr'
      ? await zt.ocr(services.imageUrl(item), def.options || {})
      : await zt.translate(item.text, def.options || {})
    App.showResult(def.name, (result && result.text) || '')
  } catch (e) {
    App.toast(`${def.name}失败：${e.message || e}`)
  }
}

function runCustomAction(def, item) {
  const text = item.type === 'text' ? item.text : item.type === 'file' ? item.files.map((f) => f.path).join('\n') : ''
  if (def.provider) return runProviderAction(def, item)
  if (def.url) {
    window.ztools.shellOpenExternal(def.url.replace(/\{text\}/g, encodeURIComponent(text)))
    return
  }
  let payload = text
  if (item.type === 'image') {
    // 图片先写入剪贴板，同时以 Data URL 形式传递
    services.copy([item])
    payload = services.imageUrl(item)
  }
  const ok = window.ztools.redirect(def.redirect, payload)
  if (ok === false) {
    const label = Array.isArray(def.redirect) ? def.redirect.join(' / ') : def.redirect
    App.toast(`未找到指令「${label}」，请确认已安装对应插件`)
  }
}

const Actions = {
  cache: null,
  // 配置变更后调用
  reset() {
    this.cache = null
  },
  load() {
    if (!this.cache) {
      const config = services.getConfig()
      const custom = (config.customActions || []).filter((d) => d && d.id && d.name).map(customAction)
      this.cache = { all: [...BUILTIN_ACTIONS, ...custom], toolbar: config.toolbar || [] }
    }
    return this.cache
  },
  all() {
    return this.load().all
  },
  for(item) {
    return this.all().filter((a) => a.when(item))
  },
  toolbarFor(item) {
    const { all, toolbar } = this.load()
    return toolbar.map((id) => all.find((a) => a.id === id)).filter((a) => a && a.when(item))
  }
}
