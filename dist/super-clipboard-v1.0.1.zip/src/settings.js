// 设置页
const MAX_TOOLBAR = 8
// 发布前替换为实际地址
const LINKS = [
  { name: '作者主页', url: 'https://github.com/' },
  { name: '使用帮助', url: 'https://github.com/' },
  { name: '论坛', url: 'https://github.com/ZToolsCenter/ZTools/discussions' },
  { name: '开源地址', url: 'https://github.com/' },
  { name: '赞赏', url: 'https://afdian.com/' }
]

const CUSTOM_ACTION_HELP = `每个操作是一个对象：
  id       唯一标识
  name     显示名称
  types    适用类型，可选 "text" / "image" / "file"
  match    （可选）文字需匹配的正则，不匹配时不显示
  以下三选一：
  provider "ocr" 或 "translation"，调用 ZTools 中已启用的 OCR / 翻译服务，结果在弹窗中显示
  redirect 转给的插件指令："指令名" 或 ["插件名", "指令名"]
  url      打开网址，{text} 会被替换为内容`

const Settings = {
  el: document.getElementById('settings'),

  isOpen() {
    return !this.el.classList.contains('hidden')
  },

  open() {
    this.render()
    this.el.classList.remove('hidden')
  },

  close() {
    this.el.classList.add('hidden')
    this.el.innerHTML = ''
  },

  // 保存配置并刷新主界面
  save(patch) {
    services.setConfig(patch)
    Actions.reset()
    App.refresh({ keepCursor: true })
  },

  render() {
    const config = services.getConfig()
    const status = services.listenerStatus()
    const actions = Actions.all()
    const modeText = status.mode === 'native'
      ? '<span class="ok">已安装监听程序，正在使用原生监听</span>'
      : '<span class="warn">未检测到监听程序，正在使用内置轮询监听（可正常记录，资源占用略高）</span>'

    this.el.innerHTML = `
      <div class="settings-head">
        <span>设置</span>
        <button class="icon-btn" data-s="close" title="关闭 (Esc)">${icon('close')}</button>
      </div>
      <div class="settings-body">
        <section>
          <h3>剪贴板监听</h3>
          <p>${modeText}</p>
          <details>
            <summary>安装说明</summary>
            <ol>
              <li>准备一个监听程序：剪贴板内容每变化一次，就向标准输出打印一行文字（内容不限）。</li>
              <li>把它重命名为 <code>${esc(status.path.split(/[\\/]/).pop())}</code>，放到下面的目录（macOS / Linux 需执行 <code>chmod +x</code> 赋予执行权限）：<br><code>${esc(status.path)}</code></li>
              <li>点击「重新检测」。未安装时插件会自动使用内置的轮询方式记录，功能不受影响。</li>
              <li>插件在后台运行期间才会记录；彻底退出插件或重启 ZTools 后，需要重新打开一次插件。</li>
            </ol>
          </details>
          <div class="btns"><button data-s="listener-dir">打开目录</button><button data-s="listener-check">重新检测</button></div>
        </section>

        <section>
          <h3>记录存放位置</h3>
          <p class="path">${esc(config.dataDir)}</p>
          <p class="muted">放到网盘目录（如 iCloud、OneDrive、坚果云）即可在多台设备之间同步。切换到已有记录的目录时直接使用该目录的记录，否则把当前记录复制过去。</p>
          <div class="btns"><button data-s="dir-change">修改</button><button data-s="dir-open">打开</button></div>
        </section>

        <section>
          <h3>记录保留</h3>
          <label class="range">最大记录条数 <input type="range" min="500" max="1000" step="50" value="${config.maxCount}" data-s="maxCount" /><b>${config.maxCount}</b> 条</label>
          <label class="range">最长保存时间 <input type="range" min="1" max="31" step="1" value="${config.maxDays}" data-s="maxDays" /><b>${config.maxDays}</b> 天</label>
          <p class="muted">收藏的内容不受以上限制。</p>
        </section>

        <section>
          <h3>主界面操作按钮 <span class="muted" id="toolbar-count">${config.toolbar.length}/${MAX_TOOLBAR}</span></h3>
          <div class="checks">${actions
            .map((a) => `<label><input type="checkbox" data-toolbar="${esc(a.id)}" ${config.toolbar.includes(a.id) ? 'checked' : ''} />${esc(a.name)}</label>`)
            .join('')}</div>
          <p class="muted">按钮只在适用的条目上显示，其余操作可通过右键或「更多」菜单使用。</p>
        </section>

        <section>
          <h3>自定义操作</h3>
          <pre class="help">${esc(CUSTOM_ACTION_HELP)}</pre>
          <textarea id="custom-actions" spellcheck="false">${esc(JSON.stringify(config.customActions, null, 2))}</textarea>
          <div class="btns"><button class="primary" data-s="custom-save">保存自定义操作</button></div>
        </section>

        <section>
          <h3>其他</h3>
          <div class="btns">
            <button data-s="reset">恢复默认设置</button>
            <button class="danger" data-s="clear">清空全部记录</button>
          </div>
        </section>

        <section>
          <h3>关于</h3>
          <div class="btns">${LINKS.map((l) => `<button data-link="${esc(l.url)}">${esc(l.name)}</button>`).join('')}</div>
        </section>
      </div>`

    this.bind()
  },

  bind() {
    const el = this.el
    el.onclick = async (e) => {
      const link = e.target.closest('[data-link]')
      if (link) return window.ztools.shellOpenExternal(link.dataset.link)
      const btn = e.target.closest('button[data-s]')
      if (!btn) return
      switch (btn.dataset.s) {
        case 'close':
          return this.close()
        case 'listener-dir':
          return services.openListenerDir()
        case 'listener-check':
          services.restartListener()
          this.render()
          return App.toast(services.listenerStatus().mode === 'native' ? '已启用原生监听' : '未检测到监听程序')
        case 'dir-change':
          try {
            if (services.chooseDataDir()) {
              this.render()
              App.refresh()
              App.toast('存放位置已修改')
            }
          } catch (err) {
            App.toast('修改失败：' + err.message)
          }
          return
        case 'dir-open':
          return services.openDataDir()
        case 'custom-save':
          return this.saveCustomActions()
        case 'reset':
          if (await confirmDialog('恢复默认设置？记录和存放位置不受影响。', '恢复')) {
            services.resetConfig()
            Actions.reset()
            App.refresh({ keepCursor: true })
            this.render()
            App.toast('已恢复默认设置')
          }
          return
        case 'clear':
          if (await confirmDialog('清空全部记录？收藏的内容也会被清空，此操作不可恢复。', '全部清空')) {
            services.clearAll()
            App.toast('已清空')
          }
          return
      }
    }

    el.oninput = (e) => {
      const input = e.target
      if (input.type === 'range') input.nextElementSibling.textContent = input.value
    }

    el.onchange = (e) => {
      const input = e.target
      if (input.type === 'range') this.save({ [input.dataset.s]: +input.value })
      if (input.dataset.toolbar) {
        const toolbar = [...el.querySelectorAll('[data-toolbar]:checked')].map((c) => c.dataset.toolbar)
        if (toolbar.length > MAX_TOOLBAR) {
          input.checked = false
          return App.toast(`最多选择 ${MAX_TOOLBAR} 个`)
        }
        this.save({ toolbar })
        el.querySelector('#toolbar-count').textContent = `${toolbar.length}/${MAX_TOOLBAR}`
      }
    }
  },

  saveCustomActions() {
    let list
    try {
      list = JSON.parse(this.el.querySelector('#custom-actions').value)
      if (!Array.isArray(list)) throw new Error('必须是数组')
      const ids = new Set()
      for (const a of list) {
        if (!a || typeof a !== 'object') throw new Error('每一项必须是对象')
        if (!a.id || !a.name) throw new Error('每一项都需要 id 和 name')
        if (ids.has(a.id)) throw new Error(`id 重复：${a.id}`)
        ids.add(a.id)
        if (!a.redirect && !a.url && !a.provider) throw new Error(`「${a.name}」需要 provider、redirect 或 url`)
        if (a.provider && !['ocr', 'translation'].includes(a.provider)) throw new Error(`「${a.name}」的 provider 只能是 ocr 或 translation`)
        if (a.types && (!Array.isArray(a.types) || a.types.some((t) => !['text', 'image', 'file'].includes(t)))) {
          throw new Error(`「${a.name}」的 types 只能包含 text、image、file`)
        }
        if (a.match) new RegExp(a.match)
      }
    } catch (err) {
      return App.toast('格式错误：' + err.message)
    }
    // 移除已不存在的自定义操作按钮
    const valid = new Set([...BUILTIN_ACTIONS.map((a) => a.id), ...list.map((a) => 'custom:' + a.id)])
    const toolbar = services.getConfig().toolbar.filter((id) => valid.has(id))
    this.save({ customActions: list, toolbar })
    this.render()
    App.toast('已保存')
  }
}
