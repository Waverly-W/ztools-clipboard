const fs = require('fs')
const os = require('os')
const path = require('path')
const { Store } = require('./lib/store')
const { Watcher } = require('./lib/clipboard')

const BASE_DIR = path.join(os.homedir(), '.ztools-clipboard')
const LISTENER_PATH = path.join(BASE_DIR, 'bin', process.platform === 'win32' ? 'clipboard-listener.exe' : 'clipboard-listener')
const CONFIG_KEY = 'config'

const DEFAULT_CONFIG = {
  dataDir: path.join(BASE_DIR, 'data'),
  maxCount: 800,
  maxDays: 14,
  toolbar: ['copy', 'view', 'fav', 'editFav', 'delete'],
  // redirect: 指令名称 或 [插件名称, 指令名称]；url 中的 {text} 会被替换为内容
  // provider: 'ocr' | 'translation'，调用 ZTools 中已启用的 OCR / 翻译服务
  // types: 适用的内容类型；match: 文字需匹配的正则（可选）
  customActions: [
    { id: 'translate', name: '翻译', types: ['text'], provider: 'translation' },
    { id: 'baidu', name: '百度搜索', types: ['text'], url: 'https://www.baidu.com/s?wd={text}' },
    { id: 'wordCount', name: '统计字数', types: ['text'], redirect: '统计字数' },
    {
      id: 'color',
      name: '识别颜色值',
      types: ['text'],
      match: '^\\s*(#([0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|(rgb|hsl)a?\\([^)]*\\))\\s*$',
      redirect: '颜色'
    },
    { id: 'ocr', name: 'OCR 文字识别', types: ['image'], provider: 'ocr' },
    { id: 'imageHost', name: '上传图床', types: ['image'], redirect: '上传到图床' },
    { id: 'baiduImage', name: '百度识图', types: ['image'], redirect: '百度识图' },
    { id: 'qrcode', name: '识别二维码', types: ['image'], redirect: '识别二维码' },
    { id: 'memo', name: '收藏到备忘快贴', types: ['text', 'image'], redirect: '备忘快贴' }
  ]
}

const zt = () => window.ztools

function loadConfig() {
  let saved = null
  try { saved = zt().dbStorage.getItem(CONFIG_KEY) } catch {}
  return { ...DEFAULT_CONFIG, ...(saved || {}) }
}

let config = loadConfig()
let store
try {
  store = new Store(config.dataDir)
} catch (e) {
  // 自定义目录不可用（如网盘未挂载）时退回默认目录
  console.error('[clipboard] data dir unavailable', e)
  store = new Store(DEFAULT_CONFIG.dataDir)
}

function cleanup() {
  store.cleanup({ maxCount: config.maxCount, maxDays: config.maxDays })
}

const watcher = new Watcher((entry) => {
  store.add(entry)
  cleanup()
})
watcher.start(LISTENER_PATH)
cleanup()
setInterval(cleanup, 60 * 60 * 1000)
window.addEventListener('beforeunload', () => {
  watcher.stop()
  store.flush()
})

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const thumbCache = new Map()

function itemPaths(item) {
  if (item.type === 'file') return item.files.map((f) => f.path)
  if (item.type === 'image') return [store.imagePath(item)]
  return []
}

window.services = {
  // ---------- 记录 ----------
  getItems: () => store.items,
  getItem: (id) => store.get(id),
  onChange: (fn) => store.onChange(fn),
  sync: () => {
    store.syncFromDisk()
    cleanup()
  },
  remove: (ids) => store.remove(ids),
  clearAll: () => store.clear(),
  favorite: (ids, tags = []) => {
    for (const id of ids) {
      const item = store.get(id)
      if (item && !item.fav) store.update(id, { fav: true, favTime: Date.now(), tags: item.tags || tags })
    }
  },
  unfavorite: (ids) => {
    for (const id of ids) store.update(id, { fav: false, tags: [] })
    cleanup()
  },
  editFavorite: (id, { text, tags }) => {
    const item = store.get(id)
    if (!item) return
    const patch = { fav: true, favTime: item.favTime || Date.now(), tags }
    if (item.type === 'text' && typeof text === 'string' && text.trim()) patch.text = text
    store.update(id, patch)
  },

  // ---------- 图片 / 文件 ----------
  imagePath: (item) => store.imagePath(item),
  imageUrl: (item) => {
    const { nativeImage } = require('electron')
    return nativeImage.createFromPath(store.imagePath(item)).toDataURL()
  },
  thumbUrl: (item) => {
    if (thumbCache.has(item.image)) return thumbCache.get(item.image)
    const { nativeImage } = require('electron')
    let img = nativeImage.createFromPath(store.imagePath(item))
    if (img.isEmpty()) return ''
    const { width, height } = img.getSize()
    if (width > 160 || height > 160) {
      img = width >= height ? img.resize({ width: 160 }) : img.resize({ height: 160 })
    }
    const url = img.toDataURL()
    thumbCache.set(item.image, url)
    return url
  },
  fileExists: (p) => fs.existsSync(p),
  openFolder: (item) => {
    const p = itemPaths(item)[0]
    if (p) zt().shellShowItemInFolder(p)
  },
  openPath: (p) => zt().shellOpenPath(p),
  saveAsFile: (item) => {
    const isImage = item.type === 'image'
    const target = zt().showSaveDialog({
      title: '保存为文件',
      defaultPath: path.join(zt().getPath('downloads'), `clipboard-${Date.now()}.${isImage ? 'png' : 'txt'}`),
      filters: isImage ? [{ name: '图片', extensions: ['png'] }] : [{ name: '文本', extensions: ['txt', 'md'] }]
    })
    if (!target) return false
    if (isImage) fs.copyFileSync(store.imagePath(item), target)
    else fs.writeFileSync(target, item.text, 'utf8')
    return target
  },

  // ---------- 复制 / 粘贴 ----------
  // 多条内容：全是文字则换行拼接；没有文字则合并为文件（图片以图片文件形式）
  copy: (items) => {
    const texts = items.filter((i) => i.type === 'text')
    if (texts.length === items.length) return zt().copyText(texts.map((i) => i.text).join('\n'))
    if (items.length === 1 && items[0].type === 'image') return zt().copyImage(store.imagePath(items[0]))
    if (!texts.length) return zt().copyFile(items.flatMap(itemPaths))
    zt().copyText(texts.map((i) => i.text).join('\n'))
    return 'partial'
  },
  paste: async (items) => {
    const texts = items.filter((i) => i.type === 'text')
    if (texts.length === items.length) return zt().hideMainWindowPasteText(texts.map((i) => i.text).join('\n'))
    if (items.length === 1 && items[0].type === 'image') return zt().hideMainWindowPasteImage(store.imagePath(items[0]))
    if (!texts.length) return zt().hideMainWindowPasteFile(items.flatMap(itemPaths))
    // 文字和图片/文件混合时逐条粘贴
    for (const item of items) {
      if (item.type === 'text') zt().hideMainWindowPasteText(item.text)
      else if (item.type === 'image') zt().hideMainWindowPasteImage(store.imagePath(item))
      else zt().hideMainWindowPasteFile(itemPaths(item))
      await sleep(300)
    }
    return true
  },
  pasteText: (text) => zt().hideMainWindowPasteText(text),
  copyText: (text) => zt().copyText(text),

  // ---------- 设置 ----------
  getConfig: () => JSON.parse(JSON.stringify(config)),
  getDefaultConfig: () => JSON.parse(JSON.stringify(DEFAULT_CONFIG)),
  setConfig: (patch) => {
    config = { ...config, ...patch }
    zt().dbStorage.setItem(CONFIG_KEY, config)
    cleanup()
    return config
  },
  // 恢复默认设置，保留记录存放位置
  resetConfig: () => {
    config = { ...DEFAULT_CONFIG, dataDir: config.dataDir }
    zt().dbStorage.setItem(CONFIG_KEY, config)
    cleanup()
    return config
  },
  chooseDataDir: () => {
    const dirs = zt().showOpenDialog({
      title: '选择记录存放位置',
      defaultPath: config.dataDir,
      properties: ['openDirectory', 'createDirectory']
    })
    if (!dirs || !dirs[0]) return null
    store.moveTo(dirs[0])
    window.services.setConfig({ dataDir: dirs[0] })
    return dirs[0]
  },
  openDataDir: () => zt().shellOpenPath(config.dataDir),
  listenerStatus: () => ({
    path: LISTENER_PATH,
    installed: fs.existsSync(LISTENER_PATH),
    mode: watcher.mode
  }),
  restartListener: () => {
    watcher.start(LISTENER_PATH)
    return watcher.mode
  },
  openListenerDir: () => {
    fs.mkdirSync(path.dirname(LISTENER_PATH), { recursive: true })
    zt().shellOpenPath(path.dirname(LISTENER_PATH))
  }
}
